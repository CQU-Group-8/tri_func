##########
# 项目名称：Tri-Func-Calculator-CQU
# 最终版本：Tri-Func-Calculator-CQU
# 修订时间：2022年4月1日
# 小组成员：林康志、杜建建、钟豪、朱思宁、戚俊
# 程序说明: 定义主函数。
##########

from calculator import *

if __name__ == '__main__':
    calc = Calculator()
    calc.screen.mainloop()
